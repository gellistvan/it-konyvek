uv pip install ipykernel
uv run python -m ipykernel install --user --name cnn-labor --display-name "CNN labor (lab/.venv)"
jupyter kernelspec list   # a cnn-labor kernel.json argv[0] mezője: .../lab/.venv/bin/python

import torch
import torch.nn as nn

torch.manual_seed(7)
model = nn.Sequential(*[nn.Conv2d(1, 1, 3, padding=1, bias=False) for _ in range(4)])
with torch.no_grad():                       # degenerált súlyok: csak a középső elem 1
    for m in model:
        m.weight.zero_()
        m.weight[0, 0, 1, 1] = 1.0
x = torch.ones(1, 1, 32, 32, requires_grad=True)
out = model(x)
out[0, 0, 16, 16].backward()
g = x.grad[0, 0].abs()
nz = int((g > 1e-8).sum())
mid = g[15:18, 15:18].sum().item() / g.sum().item()
assert nz == 1 and mid == 1.0
print("nemnulla elemek:", nz, "| közép 3x3 arány:", f"{mid:.3f}")

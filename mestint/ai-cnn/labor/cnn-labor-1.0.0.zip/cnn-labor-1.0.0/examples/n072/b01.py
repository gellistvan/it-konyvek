import numpy as np

def scene_bootstrap_ci(delta, n_boot=2000, seed=0):
    """delta: jelenetenkénti l_res - l_plain egy seedre; 95%-os percentilis-intervallum."""
    rng = np.random.default_rng(seed)
    delta = np.asarray(delta, dtype=np.float64)
    idx = rng.integers(0, len(delta), size=(n_boot, len(delta)))
    return np.percentile(delta[idx].mean(axis=1), [2.5, 97.5])
